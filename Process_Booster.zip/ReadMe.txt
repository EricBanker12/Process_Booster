This small program will let you more easily set the active window's process priority and affinity (which CPU cores the process may access).

Installation: Extract the .zip folder to your desired installation directory and run Process_Booster.exe

Uninstallation: Delete the extracted folder and contents.

Usage: With Process_Booster.exe running and the window of the desired process active, press the activation hotkey (by default Ctrl+Shift+F) to open a window to set process priority and affinity.